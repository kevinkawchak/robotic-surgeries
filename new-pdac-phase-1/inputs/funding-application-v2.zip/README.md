# Clinical Trial Funding Application v2 - LaTeX Source

This package retains the original source structure:

- `main.tex`
- `clinicaltrialgrant.sty`
- `references.bib`
- `sections/`
- `sections/ai-peer-review-context.tex` (centralized v2 AI provenance and peer-review wording)
- `README.md`

It is configured by default to compile a standard static PDF. The Phase 1 Protocol context, color scheme, seven Mermaid-type TikZ figures, stable bibliography labels, and revised LLM/robotic Whipple content are embedded in the existing files.


## v2 AI provenance and peer-review context

All substantive v2 wording about the Daraxonrasib development timeline, Claude Code production role, ChatGPT Codex and Google Gemini peer-review roles, mid-project review, and application-generation disclosure is maintained in:

```latex
sections/ai-peer-review-context.tex
```

The Project Summary and Research Strategy call macros from that single file. Edit the macros there rather than duplicating the narrative in multiple section files. The v2 source deliberately uses only the general AI-peer-review rationale from the supplied peer-review paper; it does not import its glioblastoma study narrative.

## 1. Output mode

Near the top of `clinicaltrialgrant.sty`:

```latex
\FieldPDFfalse  % ordinary static PDF
```

Use `\FieldPDFtrue` only when an editable AcroForm draft is specifically needed. Static output omits the PDF form environment and is the recommended submission/printing mode.

## 2. Edit application content

Applicant and opportunity details are located in the existing section files. Start with:

- `sections/00-cover-and-transmittal.tex`
- `sections/01-opportunity-and-organization.tex`
- `sections/02-project-summary.tex`
- `sections/03-research-strategy.tex`

Fields use:

```latex
\field[
  id=project-abstract,
  font=10pt,
  height=3in,
  max=3200,
  bottom=8pt
]{Project Summary / Abstract}{%
  Application text.
}
```

Table values use `\cell[...] {...}`. Use `\FieldPara` for a single blank line between paragraphs inside a field; do not use caret-coded forced-line-break sequences.

### Checkbox items

Unchecked and checked checklist rows use parallel commands:

```latex
\checkitem{unique-field-name}{Unchecked item text.}
\checkeditem{unique-field-name}{Checked item text.}
```

The checked form uses the same box dimensions and border/background styling as `\checkitem`, with a centered, inset X that remains inside the box. In fillable mode, the checked box is initialized as selected and remains interactive. Each field name must be unique.

## 3. Phase 1 Protocol figures and colors

The figure pages use TikZ with the Phase 1 Protocol palette:

- blue `#00417A`
- professional grayscale `#6C757D`
- light grays `#E9ECEF` and `#D9D9D9`
- dark gray `#222222`

Subheadings use the professional gray. Included figures are 1, 2, 3, 6, 8, 12, and 16. They are kept in the existing section files and may increase the compiled page count without expanding the five-page Pioneer Essay.

## 4. Citations and bibliography

Use the field-safe citation command:

```latex
\fcite{phase1ind,onpremwhippl}
```

Every bibliography entry is prepended in the PDF by its stable label, such as `[Kawchak, 2026q]`, while retaining the normal BibTeX entry and hyperlink anchor.

## 5. Compile in Overleaf or locally

Use pdfLaTeX and BibTeX:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

The same sequence is compatible with an Overleaf project configured for pdfLaTeX. Before submission, inspect the generated PDF at 100% zoom and print preview, and recheck all live NIH instructions, registrations, institutional commitments, FDA/IRB status, and application-form validation.

## 6. Use notice

This is a drafting package, not an official agency application form. It does not replace NIH ASSIST, Grants.gov Workspace, institutional system-to-system submission, SF424 forms, IRB review, FDA submissions, institutional authorization, legal review, or the live solicitation.
