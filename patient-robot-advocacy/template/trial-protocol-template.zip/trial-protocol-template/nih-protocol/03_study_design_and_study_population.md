# STUDY POPULATION

- No text is to be entered in this section; rather it should be included under the relevant subheadings below.

The following subsections should include a description of the study population and participant recruitment. The study population should be appropriate for clinical trial phase and the development stage of the study intervention.  Given the continuing challenges in achieving clinically relevant demographic inclusion in clinical trials, it is important to focus on clinically relevant potential participants at the earliest stages of protocol development.  Therefore, it is essential that the population’s characteristics be considered during the trial planning phase to ensure the trial can adequately meet its objectives and provide evidence for the total population that will potentially utilize the study intervention under evaluation (e.g., elderly and pediatric populations, women, and minorities).

Use the following guidelines when developing participant eligibility criteria to be listed in **S****ections ****5.1 ****Inclusion Criteria ****and ****5.2**** ****Exclusion Criteria**:

The eligibility criteria should provide a definition of participant characteristics required for study entry/enrollment. 

If participants require screening, distinguish between screening participants vs enrolling participants. Determine if screening procedures will be performed under a separate screening consent form.

The risks of the study intervention should be considered in the development of the inclusion/exclusion criteria so that risks are minimized.

The same criterion should not be listed as both an inclusion and exclusion criterion (e.g., do not state age >18 years old as an inclusion criterion and age ≤18 years old as an exclusion criterion).

Identify specific laboratory tests or clinical characteristics that will be used as criteria for enrollment or exclusion.

If reproductive status (e.g., pregnancy, lactation, reproductive potential) is an eligibility criterion, provide specific contraception requirements (e.g., licensed hormonal or barrier methods). 

If you have more than one study population, please define the common inclusion and exclusion criteria followed by the specific inclusion and exclusion criteria for each subpopulation. 

## Inclusion Criteria

Inclusion criteria are characteristics that define the population under study, e.g., those criteria that every potential participant must satisfy, to qualify for study entry. Provide a statement that individuals must meet all of the inclusion criteria in order to be eligible to participate in the study and then list each criterion. Women and members of minority groups must be included in accordance with the NIH Policy on Inclusion of Women and Minorities as Participants In Research Involving Human Subjects. 

Some criteria to consider for inclusion are: provision of appropriate consent and assent, willingness and ability to participate in study procedures, age range, health status, specific clinical diagnosis or symptoms, background medical treatment, laboratory ranges, and use of appropriate contraception. Additional criteria should be included as appropriate for the study design and risk. 

Example text provided as a guide, customize as needed:  

[In order to be eligible to participate in this study, an individual must meet all of the following criteria:

- Provision of signed and dated informed consent form

- Stated willingness to comply with all study procedures and availability for the duration of the study 

- Male or female, aged <specify range>

- In good general health as evidenced by medical history or diagnosed with <specify condition/disease> or exhibiting <specify clinical signs or symptoms or physical/oral examination findings>

- <Specify laboratory test> results between <specify range>

- Ability to take oral medication and be willing to adhere to the <study intervention> regimen

- For females of reproductive potential: use of highly effective contraception for at least 1 month prior to screening and agreement to use such a method during study participation and for an additional <specify duration> weeks after the end of <study intervention> administration 

- For males of reproductive potential: use of condoms or other methods to ensure effective contraception with partner

- Agreement to adhere to Lifestyle Considerations (see section 5.3) throughout study duration]

<Insert text>

## Exclusion Criteria

Exclusion criteria are characteristics that make an individual ineligible for study participation.  Provide a statement that all individuals meeting any of the exclusion criteria at baseline will be excluded from study participation and then list each criterion.  If specific populations are excluded (e.g., elderly or pediatric populations, women or minorities), provide a clear and compelling rationale and justification, to establish that inclusion is inappropriate with respect to the health of the participants or the purpose of the research. Limited English proficiency cannot be an exclusion criterion. 

Some criteria to consider for exclusion are: pre-existing conditions or concurrent diagnoses, concomitant use of other medication(s) or devices, known allergies, other factors that would cause harm or increased risk to the participant or close contacts, or preclude the participant’s full adherence with or completion of the study. Additional criteria should be included as appropriate for the study design and risk. 

*Include **a **statement regarding equitable selection or justification for excluding a specific population.*

Example text provided as a guide, customize as needed (including adding a statement about equitable selection):  

[An individual who meets any of the following criteria will be excluded from participation in this study:

- Current use of < specify disallowed concomitant medications*>** *

- Presence of <specific devices (e.g., cardiac pacemaker)>

- Pregnancy or lactation

- Known allergic reactions to components of the <study intervention>, <specify components/allergens>

- Febrile illness within <specify time frame*>* 

- Treatment with another investigational drug or other intervention within *<*specify time frame*>*

- Current smoker or tobacco use within *<*specify timeframe*>*

- < Specify any condition(s) or diagnosis, both physical or psychological, or physical exam finding that precludes participation>]

<Insert text>

## Lifestyle Considerations

- Include content in this section if applicable, otherwise note as not-applicable.

*Describe any restrictions during any **parts **of the study** **pertain**in**g to lifestyle and/or diet (e.g., food and drink restrictions, timing of meals relative to dosing, intake of caf**f**eine, alcohol, or tobacco, or limits on activity**), and considerations for household contacts**.  **Describe what action will be taken if prohibited medications, treatments or procedu**res are indicated for care (e.g.,** early withdraw**al).*

*Example text** provided as a guide, customize as needed**:*

[During this study, participants are asked to:

- Refrain from consumption of red wine, Seville oranges, grapefruit or grapefruit juice, [pomelos, exotic citrus fruits, grapefruit hybrids, or fruit juices] from [X days] before the start of <study intervention> until after the final dose.

- Abstain from caffeine- or xanthine-containing products (e.g., coffee, tea, cola drinks, and chocolate) for [x hours] before the start of each dosing session until after collection of the final pharmacokinetic (PK) and/or pharmacodynamic sample.

- Abstain from alcohol for 24 hours before the start of each dosing session until after collection of the final PK and/or pharmacodynamic sample. 

- Participants who use tobacco products will be instructed that use of nicotine-containing products (including nicotine patches) will not be permitted while they are in the clinical unit. 

- Abstain from strenuous exercise for [x hours] before each blood collection for clinical laboratory tests. Participants may participate in light recreational activities during studies (e.g., watching television, reading). 

- Minimize interactions with household contacts who may be immunocompromised.]

<Insert text>

## Screen Failures

Participants who are consented to participate in the clinical trial, who do not meet one or more criteria required for participation in the trial during the screening procedures, are considered screen failures.  Indicate how screen failures will be handled in the trial, including conditions and criteria upon which re-screening is acceptable, when applicable.

Example text provided as a guide, customize as needed:  

[Screen failures are defined as participants who consent to participate in the clinical trial but are not subsequently randomly assigned to the study intervention or entered in the study. A minimal set of screen failure information is required to ensure transparent reporting of screen failure participants, to meet the Consolidated Standards of Reporting Trials (CONSORT) publishing requirements and to respond to queries from regulatory authorities. Minimal information includes demography, screen failure details, eligibility criteria, and any serious adverse event (SAE).

Individuals who do not meet the criteria for participation in this trial (screen failure) because of a <specify modifiable factor> may be rescreened. Rescreened participants should be assigned the same participant number as for the initial screening.]

<Insert text>

## Strategies for Recruitment and Retention

Identify general strategies for participant recruitment and retention.  This section may refer to a separate detailed recruitment and retention plan in the manual of procedures (MOP) and site specific plans could be included in a site-specific standard operating procedure (SOP).  Consider inclusion of the information below either in this section or the MOP.  

- *T**arget **study **sample size** by gender, race and ethnicity, and age**; identify anticipated number to be screened **including women and minorities **in order to** reach the target enrollment* (should be consistent with information contained in **Section ****9.****2****, Sample Size**** Determination**)

- Anticipated accrual rate

- Anticipated number of sites and participants to be enrolled from the U.S. and outside the U.S.

- Source of participants *(e.g., inpatient hospital setting, outpatient clinics, student health service, or **general public**)*

- Recruitment venues

- How potential participants will be identified and approached

- Types of recruitment strategies planned (e.g. patient advocacy groups, national newspaper, local flyers; social media, specific names of where advertisements may be planned are not needed)

- If the study requires long-term participation, describe procedures that will be used to enhance participant retention (e.g., multiple methods for contacting participants, visit reminders, incentives for visit attendance). 

- *Specific strategies that will be used to recruit and retain historically under-represented populations in order to meet target sample size** and *conform with the NIH Policy on Inclusion of Women and Minorities as Participants In Research Involving Human Subjects.  Include the number of women and minorities expected to be recruited, or provide justification on those rare occasions where women and/or minorities will not be recruited. 

- In addition, this section should address:

- If appropriate, include justification for inclusion of vulnerable participants and recruitment strategy.  Vulnerable participants include, but are not limited to pregnant women, those who lack consent capacity, including the mentally ill, prisoners, cognitively impaired participants, children, and employee volunteers.  Include safeguards for protecting vulnerable populations.  Please refer to OHRP guidelines when choosing the study population. Note that these regulations apply if any participants are members of the designated population, even if it is not the target population (e.g., if a participant becomes a prisoner during the study).

- *If **participant**s will be compensated **or provided any incentives *(e.g. vouchers, gift cards,) *for study participation, describe amount**, form** and **timing of such compensation in relation to study activities (include financial and non-financial incentives).  Describe who will receive incentives (if not the **participant**).  For example, if minors, state whether the minor or the parent/guardian will receive the incentive.  If incapacitated adult**s**, state if payment will be provided to the **participant** or to a** legally authorized representative or **guardian. *

<Insert text>

