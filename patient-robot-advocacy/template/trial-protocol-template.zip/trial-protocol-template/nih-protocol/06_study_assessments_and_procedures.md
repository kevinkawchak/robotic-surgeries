# STUDY ASSESSMENTS AND PROCEDURES

- No text is to be entered in this section; rather it should be included under the relevant subheadings below.

## Efficacy Assessments 

*List and describe all study procedures and evaluations to be done as part of the study** to support the determination of efficacy**, as per the primary and secondary objectives **outlined **in this protocol**. **Discuss the sequence of events that should occur during **the **screening** process** and **any** decision points regarding **participant **eligibility.  **Include** the time frame prior to enrollment within which screening **procedures/** evaluations must be performed (e.g., within 28 days prior to enrollment).**  If a separate screening protocol is developed, describe how the screening protocol will be used to identify participants for this study.** In addition, discuss any special conditions that must be achieved during the enrollment and/or initial administration of study **intervention**. **Include** the procedures for administering the study **intervention **and follow-up procedures after administration (e.g., assessment of vital signs)**, as well as any specifics about subsequent follow-up visits**, and unscheduled visits**.** Also, note **if** a specifically qualified person (e.g., physician, psychologist) should be performing any of the assessments. Include any definitions used to characterize outcomes (e.g., criteria for determining occurrence of acute myocardial infarction, characterization of a stroke as thrombotic or hemorrhagic, distinction between transient ischemic attack and stroke), should be explained fully. *

*For participants that may **discontinue **or withdraw early, it is important to capture **the **rationale during th**e** final visit. See ****Section 7, Study ******Intervention****** ******Discontinuation ******and Participant ******Discontinuation******/Withdrawal****, for details. *

*Note that t**he protocol should provide a high-level discussion of all procedures and detailed information can be further provided in a MOP or SOP.  Provide justification for any s**ensitive procedures (e.g., provocative testing, deception).  **In addition, **note** where approaches to **decrease variability, such as centralized laboratory assessments**, are being employed.** **The **specific timing of **procedures/evaluations to be done at each study visit are captured in ****Section 1.3, Schedule of Activities (****SoA**)** and the time points of these procedures do not need to be included here.** **In addition, indicate where appropriate, that procedures/evaluations will be performed by qualified personnel. *

*This section may **includ**e** a list and description of** the following procedures/evaluations**, as applicable**:*

- ***Physical examination**** (e.g., height and weight, organ systems, motor or vision assessment, or other functional abilities). If appropriate, discuss what constitutes a targeted physical examination.** *

- ***Radiographic or other imaging assessments****. State the specific imaging required and, as appropriate, provide description of what is **needed **to perform the specialized imaging. Details describing how to perform the imaging in a standard fashion** and equipment specifications** may be described in **the study’s** MOP or** a separate** SOP.*

- ***Biological specimen collection and laboratory evaluations****. Include specific test components and estimated volume and type of specimens needed for each test. Specify laboratory methods to **provide for** appropriate longitudinal and cross-sectional comparison (e.g., use of consistent laboratory method throughout study, use of single, central laboratory for multi-site studies). If more than one laboratory **will be** used, specify which evaluations will be done by each laboratory.  In addition, compliance with Clinical Laboratory Improvement Amendments (CLIA) of 1988 should be addressed.  If such compliance is not required, a brief discussion should be included explaining why this is the case.  In addition, discussion should include whether any laboratory tests (e.g., diagnostics) that will be used are being developed concurrently or are commercially available.  **Special instructions for the preparation, handling, storage, and shipment of specimens should be bri**efly explained in this section **with detaile**d discussion in the study’s MOP.*

- ***S******pecial assays or procedures required**** (e.g., immunology **assays**, pharmacokinetic studies, flow cytometry assays, microarray, DNA sequencing). For research laboratory assays, include specific assays, estimated volume and type of specimen needed for each test. If more than one laboratory **will be** used, specify which assays will be done by each laboratory.** **Special instructions for the preparation, handling, storage, and shipment of specimens should be bri**efly explained in this section **with detaile**d discussion in the study’s MOP.*

- ***Administration of questionnaires or other instruments**** for patient-reported outcomes, such as a daily diary.*

- ***P******rocedures ******that will be ******completed during the study as part of regular standard of clinical care****.*

*Include** **in this section a **discussion of the results of any study specific procedures **that **will be provided to participant (e.g., radiographic or other imaging or laboratory evaluations).* *Address when endpoints will be assessed with respect to **dosing of rescue** medication, if applicable.*

*If an individual’s medical chart or results of diagnostic tests performed as part of an individual’s regular medical care are going to be used for screening or as a part of collection of trial data, Health Insurance Portability and Accountability Act (HIPAA)** rules, **other relevant federal or state laws, and **local institutional requirements** **should be followed**,** **as applicable.  If this is the case, this section should note which information is to be obtained through review of existing data.*

<Insert text>

## Safety and Other Assessments

*List and describe all study procedures and evaluations to be done as part of the study** to **monitor safety and **support the understanding of the study **intervention’s **safety** or that are done for other purposes (e.g., screening, **eligibility, **enrollment)**. *

*Discuss the sequence of events that should occur during **the **screening** process** and **any** decision points regarding **participant **eligibility.  **Include** the time frame prior to enrollment within which screening **procedures/** evaluations must be performed (e.g., within 28 days prior to enrollment).**  If a separate screening protocol is developed, describe how the screening protocol will be used to identify participants for this study. In addition, discuss any special conditions that must be achieved during the enrollment and/or initial administration of study intervention.  *

*Note that t**he protocol should provide a high-level discussion of all procedures and detailed information can be further provided in a MOP or SOP.  **In addition, **note** where approaches to **decrease variability, such as centralized laboratory assessments**, are being employed. **The specific timing of procedures/evaluations to be done at each study visit are captured in ****Section 1.3, Schedule of Activities (******SoA******) ****and the time points of these procedures do not need to be included here. **In addition, indicate where appropriate, that procedures/evaluations will be performed by qualified personnel.*

*This section may **includ**e** **a list and description of **the following procedures/evaluations**, as applicable**:*

- ***Physical examination**** **(e.g., height and weight, organ systems, motor or vision assessment, or other functional abilities). If appropriate, discuss what constitutes a targeted physical examination. *

- ***Vital signs**** **(e.g., t**emperature, pulse, respirations, blood pressure**)**.** C**arefully consider which vital signs (if any) should be measured to ensure that only essential data are collected. Include any specific instructions with respect to the **collection and interpretation of vital signs.  *

- ***Electrocardiograms (EKGs)****: specify if the EKG is for screening purposes only. Include any specific instructions for the collection and interpretation of the EKG (e.g., time points **relative** to dosing with study **intervention **or other evaluations). If EKGs **will be** analyzed at a central laboratory, instructions for the collection (e.g., equipment), transmission and archiving of the EKG data should be summarized in this **protocol, and** further outlined in the MOP. If the EKG will be read locally, indicate how these will be handled and in what format (e.g., digital or paper), as well as instructions with respect to local review. *

- ***Radiographic or other imaging assessments.**** State the specific imaging required and, as appropriate, provide description of what is **needed** **to perform the specialized imaging. Details describing how to perform the imaging in a standard fashion** and equipment specifications** may be described in **the study’s **MOP or **a separate **SOP.*

- ***Biological specimen collection and laboratory evaluations****. Include specific test components and estimated volume and type of specimens needed for each test. Specify laboratory methods to **provide for** appropriate longitudinal and cross-sectional comparison (e.g., use of consistent laboratory method throughout study, use of single, central laboratory for multi-site studies). If more than one laboratory **will be** used, specify which evaluations will be done by each laboratory.  In addition, compliance with Clinical Laboratory Improvement Amendments (CLIA) of 1988 should be addressed.  If such compliance is not required, a brief discussion should be included explaining why this is the case.  In addition, discussion should include whether any laboratory tests (e.g., diagnostics) that will be used are being developed concurrently or are commercially available.  **Special instructions for the preparation, handling, storage, and shipment of specimens **may** **be bri**efly explained in this section**;** detaile**d discussion **should be included **in the study’s MOP.*

- ***S******pecial assays or procedures required**** (e.g., immunology **assays**, pharmacokinetic studies, flow cytometry assays, microarray, DNA sequencing). For research laboratory assays, include specific assays, estimated volume and type of specimen needed for each test.** ** If more than one laboratory **will be** used, specify which assays will be done by each laboratory.**  **Special instructions for the preparation, handling, storage, and shipment of specimens should be bri**efly explained in this section **with detaile**d discussion in the study’s MOP.*

- ***Counseling procedures, including any dietary or activity considerations**** that need to** be** adhered to during study participation**.*

- ***Assessment of study ******intervention ******adherence**** or see Study **Intervention **Compliance, section 6.4*

- ***Administration of questionnaires or other instruments**** for patient-reported outcomes, such as a daily diary.*

- ***Assessment of adverse events******.****** ****Describe provisions for follow-up of ongoing AEs/SAE**s**.*

*Include** in this section a discussion of the results of any study specific procedures that will be provided to participant (e.g., radiographic or other imaging or laboratory evaluations). *

*As previously** **noted**, if an individual’s medical chart or results of diagnostic tests performed as part of an individual’s regular medical care are going to be used for screening or as a part of collection of trial data, Health Insurance Portability and Accountability Act (HIPAA)** rules**, **other relevant federal or state laws, **and local institutional requirements** should be followed**, as applicable.  If this is the case, this section should note which information** is to be obtained through review of existing data.*

<Insert text>

*  *

## Adverse Events and Serious Adverse Events

*No text is to be **entered** in this section; rather it should be included under the relevant subheadings below.*

*The following subsections are** intended to highlight **the specific** assessments related to safety and the aspects of the study which are **proposed **to ensure the safety of trial participants.  Consider developing this section in consultation with the study Medical Monitor.  **C**onsider the risks of the study **intervention** **and other study procedures and the characteristics of the study population (e.g., vulnerable populations such as children).  This section should be tailored for specific study characteristics, including but not limited to the following:*

- *The study involves an investigational new drug or investigational device*

- *The study involves washout from current medication regimen*

- *The study involves** the use of **placebo **in a** **population with **a **diagnosed disease*

- *The study requires selection of an appropriate toxicity grading scale *

- *The study involves risks **to** individuals other than research **participant**s (e.g., household or intimate contacts or communities, study clinicians, pharmacists or interventionists, etc.)*

- *Reporting of certain events (e.g., suspected child abuse or substance abuse) is mandatory because of the study population or study design characteristics*

- *The study is conducted at multiple sites, and will require centralized safety oversight*

*In developing **this section**, consider the risks of **the study** **intervention**. Review and reference the** applicable sources of information, such as the **IB**, package insert, **device **labeling,** **literature and other sources that describe the study **intervention**.  *

### Definition of Adverse Events (AE)

*Provide the definition of an AE being used for the clinical trial.  **The FDA definition of **an AE **is used in this template since this template is for phas**e 2 or 3 IND and IDE studies. **For some studies, definitions from the OHRP **G**uidance** **on Reviewing and Reporting Unanticipated Problems Involving Risks to Subjects or Others and Adverse Events**; or **ICH **GCP** definition may be more appropriate.**  However, it is important to note that FDA regulations require reporting based on the definition included in **21 CFR 312.32 (a)** for studies performed under an IND, regardless of the definition of AE used in the protocol.*

*Example text** provided as a guide, customize as needed**:*

[Adverse event means any untoward medical occurrence associated with the use of an intervention in humans, whether or not considered intervention-related (21 CFR 312.32 (a)).]

<Insert text>

### Definition of Serious Adverse Events (SAE) 

*Provide the definition of an SAE being used for the clinical trial. **The FDA definition of **an SAE **is used in this template since this template is for phas**e 2 or 3 IND and IDE studies.  I**t is important to note that FDA regulations require reporting based on the definition included in 21 CFR 312.32 (a) for studies performed under an IND, regardless of the definition of **S**AE used in the protocol.**  **Note** that the** example text provided is from the drug regulations (21 CFR 312.32 (a)).  There is no definition for SAE in the device regulations.  Therefore, investigators should develop an appropriate definition for their study. This definition could include an unanticipated adverse device effect, but an SAE is broader than that definition.  According to 21 CFR 812.3(s), an “unanticipated adverse device effect means any serious adverse effect on health or safety or any life-threatening problem or death caused by, or associated with, a device, if that effect, problem, or death was not previously identified in nature, severity, or degree of incidence in the investigational plan or application (including a supplementary plan or application), or any other unanticipated serious problem associated with a device that relates to the rights, safety, or welfare of subjects.”*

*Example** text** provided as a guide, customize as needed**:*

[An adverse event (AE) or suspected adverse reaction is considered "serious" if, in the view of either the investigator or sponsor, it results in any of the following outcomes: death, a life-threatening adverse event, inpatient hospitalization or prolongation of existing hospitalization, a persistent or significant incapacity or substantial disruption of the ability to conduct normal life functions, or a congenital anomaly/birth defect. Important medical events that may not result in death, be life-threatening, or require hospitalization may be considered serious when, based upon appropriate medical judgment, they may jeopardize the participant and may require medical or surgical intervention to prevent one of the outcomes listed in this definition. Examples of such medical events include allergic bronchospasm requiring intensive treatment in an emergency room or at home, blood dyscrasias or convulsions that do not result in inpatient hospitalization, or the development of drug dependency or drug abuse.]

<Insert text>

### Classification of an Adverse Event

*No text is to be **entered** in this section**;** rather it should be included **under** the relevant subheadings below.*

*The following subsections** will include a discussion** of how AEs will be classified.*

#### Severity of Event

*All **AEs** will be assessed by the **study **clinician using a protocol defined grading system.  Describe the method of grading an **AE** for severity. For example, many toxicity tables are available for use and are adaptable to various study designs. Selection of a toxicity table or severity scale should be made in consultation with the** study** Medical Monitor.*

*Example text **provided as a guide, customize as needed**:*

[For adverse events (AEs) not included in the protocol defined grading system, the following guidelines will be used to describe severity. 

- **Mild**** **– Events require minimal or no treatment and do not interfere with the participant’s daily activities. 

- **Moderate**** **– Events result in a low level of inconvenience or concern with the therapeutic measures. Moderate events may cause some interference with functioning.

- **Severe**** **– Events interrupt a participant’s usual daily activity and may require systemic drug therapy or other treatment. Severe events are usually potentially life-threatening or incapacitating.  Of note, the term “severe” does not necessarily equate to “serious”.]

<Insert text>

#### Relationship to Study INTERVENTION

*All AEs will have their relationship to study **intervention** **or study participation assessed with a level of specificity appropriate to the study design. **The clinician’s assessment of an AE's relationship to study **intervention** **(drug, biologic, device) is part of the documentation process, but it is not a factor in determining what is or is not reported in the study.** **Describe the method of determining the relationship of an AE to a study **intervention**.** **If there is any doubt as to whether a clinical observation is an AE, the event should be reported**.  **Some protocols may use a binary assessment (related/not related); others may have a scale of relatedness.  Evaluation of relatedness must consider etiologies such as natural history of the underlying disease, concurrent illness, concomitant therapy, study-related procedures, accidents, and other external factors. ** **In a clinical trial, the study **intervention** **must always be **suspect**. *

*Example text **provided as a guide, customize as needed**:*

[All adverse events (AEs) must have their relationship to study intervention assessed by the clinician who examines and evaluates the participant based on temporal relationship and his/her clinical judgment. The degree of certainty about causality will be graded using the categories below. In a clinical trial, the study product must always be suspect. 

- **Related** – The AE is known to occur with the study intervention, there is a reasonable possibility that the study intervention caused the AE, or there is a temporal relationship between the study intervention and event. Reasonable possibility means that there is evidence to suggest a causal relationship between the study intervention and the AE.

- **Not Related** – There is not a reasonable possibility that the administration of the study intervention caused the event, there is no temporal relationship between the study intervention and event onset, or an alternate etiology has been established.

*OR*

- **Definitely Related**** **– There is clear evidence to suggest a causal relationship, and other possible contributing factors can be ruled out. The clinical event, including an abnormal laboratory test result, occurs in a plausible time relationship to study intervention administration and cannot be explained by concurrent disease or other drugs or chemicals. The response to withdrawal of the study intervention (dechallenge) should be clinically plausible. The event must be pharmacologically or phenomenologically definitive, with use of a satisfactory rechallenge procedure if necessary.

- **Probably Related**** **– There is evidence to suggest a causal relationship, and the influence of other factors is unlikely. The clinical event, including an abnormal laboratory test result, occurs within a reasonable time after administration of the study intervention, is unlikely to be attributed to concurrent disease or other drugs or chemicals, and follows a clinically reasonable response on withdrawal (dechallenge). Rechallenge information is not required to fulfill this definition.

- **Po****tentially**** Related**** **– There is some evidence to suggest a causal relationship (e.g., the event occurred within a reasonable time after administration of the trial medication). However, other factors may have contributed to the event (e.g., the participant’s clinical condition, other concomitant events). Although an AE may rate only as “possibly related” soon after discovery, it can be flagged as requiring more information and later be upgraded to “probably related” or “definitely related”, as appropriate.

- **Unlikely to be related**** **– A clinical event, including an abnormal laboratory test result, whose temporal relationship to study intervention administration makes a causal relationship improbable (e.g., the event did not occur within a reasonable time after administration of the study intervention) and in which other drugs or chemicals or underlying disease provides plausible explanations (e.g., the participant’s clinical condition, other concomitant treatments).

- **Not Related**** **– The AE is completely independent of study intervention administration, and/or evidence exists that the event is definitely related to another etiology. There must be an alternative, definitive etiology documented by the clinician.]

<Insert text>

#### Expectedness 

*Expected adverse reactions are AEs that are known to occur for the study **intervention** **being studied and should be collected in a standard, systematic format using a grading scale based on functional assessment or magnitude of reaction. **Identify the source of **the reference** safety information used to** **determine the expectedness of the** **AE (e.g., IB, approved labeling)**. **Expectedness **is assessed based on** the awareness of **AE**s previously observed, not **on the basis of** what might be anticipated from the properties of the study **intervention**. *

*An **AE** or suspected adverse reaction is considered "unexpected" if it is not listed in the **IB**,** package insert**, or device labeling** or is not listed at the specificity or severity that has been observed; or, if an **IB** is not required or available, is not consistent with the risk information described in the **protocol**, as amended. For example, under this definition, hepatic necrosis would be unexpected (by virtue of greater severity) if the **IB** or **package insert **referred only to elevated hepatic enzymes or hepatitis. Similarly, cerebral thromboembolism and cerebral vasculitis would be unexpected (by virtue of greater specificity) if the **IB** or package i**n**sert** listed only cerebral vascular accidents. "Unexpected," as used in this definition, also refers to **AE**s or suspected adverse reactions that are mentioned in the **IB**,** **package insert**, or device labeling** **as occurring with a class of drugs** (or other medical products)** or as anticipated from the pharmacological properties **or other characteristics **of the **study **intervention**, but are not specifically mentioned as occurring with the particu**l**ar **study **intervention** **under investigation.*

*Example text** provided as a guide, customize as needed**:*

[<Insert role> will be responsible for determining whether an adverse event (AE) is expected or unexpected.  An AE will be considered unexpected if the nature, severity, or frequency of the event is not consistent with the risk information previously described for the study intervention.]

<Insert text>

### Time Period and Frequency for Event Assessment and Follow-Up

*Describe how AEs and SAEs will be identified** and** followed until resolved or considered stable**.  **Specify procedures for recording and follow-up of AEs** and **SAEs that are consistent with the **information contained within ****Section ******8******.2******, ******S******afety ******and Other ******Assessments**** including what assessment tools will be used to monitor AEs.  Include duration of follow-up after appearance of events (e.g., 1 week, 2 months).*

*An u**nsolicited AE would occur without any prompting or in response to a general question such as “Have you noticed anything different since you started the study; began the study **intervention**, etc.” A solicited AE is one that is specifically solicited such as “Have you noticed any dry mouth since you started the study medication**?”*

- *Describe which AEs will be collected as solicited events. Plan the reporting and data collection system to avoid double capture (captured both as an unsolicited and a solicited AE).*

- *Describe how unsolicited events will be captured.*

- *Include **time period** of collection (e.g., Days 0 -28) and note how long SAEs are collected – usually collected through entire study.*

*Example text** provided as a guide, customize as needed**:*

[The occurrence of an adverse event (AE) or serious adverse event (SAE) may come to the attention of study personnel during study visits and interviews of a study participant presenting for medical care, or upon review by a study monitor.

All AEs including local and systemic reactions not meeting the criteria for SAEs will be captured on the appropriate case report form (CRF). Information to be collected includes event description, time of onset, clinician’s assessment of severity, relationship to study product (assessed only by those with the training and authority to make a diagnosis), and time of resolution/stabilization of the event. All AEs occurring while on study must be documented appropriately regardless of relationship. All AEs will be followed to adequate resolution.

Any medical condition that is present at the time that the participant is screened will be considered as baseline and not reported as an AE. However, if the study participant’s condition deteriorates at any time during the study, it will be recorded as an AE. 

Changes in the severity of an AE will be documented to allow an assessment of the duration of the event at each level of severity to be performed. AEs characterized as intermittent require documentation of onset and duration of each episode.

<Insert role or name> will record all reportable events with start dates occurring any time after informed consent is obtained until 7 (for non-serious AEs) or 30 days (for SAEs) after the last day of study participation.  At each study visit, the investigator will inquire about the occurrence of AE/SAEs since the last visit.  Events will be followed for outcome information until resolution or stabilization.]

<Insert text>

### Adverse Event Reporting 

*This section addresses responsibilities of investigators for reporting of AEs.  However, it is important to recognize that sponsors have additional responsibilities under regulations that are not described in this template and should be incorporated into relevant SOPs.  *

*Describe the AE reporting procedures, including timeframes.  **Further details should be i**nclude**d in a MOP or SOP including a** description and a flow chart of when events are reported to various oversight **(e.g., **Data and Safety Monitoring Board (DSMB)**, **safety monitoring committee, independent saf**ety monitor**)** **and regulatory groups, and what study staff are responsible for completing and signing off on the AE reports**, and** who wi**ll receive notification of AEs.  **According to 21 CFR 312.64(b), “**…**The investigator must record nonserious adverse events and report them to the sponsor according to the timetable for reporting specified in the protocol**”**.*

*In addition, list any disease-related events** (DREs)** common in the study population (e.g., expected), **which will not be reported per the standard process for reporting, as applicable**. Describe how these events will be recorded** and monitored.*

<Insert text>

### Serious Adverse Event Reporting 

*This section addresses responsibilities of investigators for **reporting of** **S**AEs.  However, it is important to recognize that sponsors have additional responsibilities under regulations that are not described in this template and should be incorporated into relevant SOPs.  *

*Describe the SAE reporting procedures, including timeframes. **Further details should be i**nclude**d in a MOP or SOP including a** description and a flow chart of when events are reported to various oversight and regulatory groups, and what study staff are responsible for completing and signing off on the SAE reports**, and** who will receive notification of SAEs. *

*Generally, any AE considered serious by the PI or Sub**-**investigator** or which meets the **definition of an SAE included in ****Sect******ion 8.******3******.2, Definition of Serious Adverse Event******s ****must be submitted on an SAE form to the **Data Coordinating Center (**DCC**)** if one exists for the study.  **Studies overseen by **a DSMB** or other independent oversight body (e.g., safety monitoring committee, independent safety monitor)**, may **be required** to **submit** **expedited** notification of all SAEs or only SAEs thought to be related to study **intervention**.**  *

*According to 21 CFR 312.**64**(**b**), “**An investigator must immediately report to the sponsor any serious adverse event, **whether or not** considered drug related, including those listed in the protocol or investigator brochure and must include an assessment of whether there is a reasonable possibility that the drug caused the event. Study endpoints that are serious adverse events (e.g., all-cause mortality) must be reported in accordance with the protocol unless there is evidence suggesting a causal relationship between the drug and the event (e.g., death from anaphylaxis). In that case, the investigator must immediately report the event to the sponsor**…”*

*According to 21 CFR 312.32(c)(1), “**the sponsor must notify FDA and all participating investigators…in an IND safety report of potential serious risks, from clinical trials or any other source, as soon as possible, but in no case later than 15 calendar days after the sponsor determines that the information qualifies for reporting… In each IND safety report, the sponsor must identify all IND safety reports previously submitted to FDA concerning a similar suspected adverse **reaction, and** must analyze the significance of the suspected adverse reaction in light of previous, similar reports or any other relevant information. The sponsor must report any suspected adverse reaction that is both serious and unexpected. The sponsor must report an adverse event as a suspected adverse reaction only if there is evidence to suggest a causal relationship between the drug and the adverse event, such as:*

*(A) A single occurrence of an event that is uncommon and known to be strongly associated with drug exposure (e.g., angioedema, hepatic injury, Stevens-Johnson Syndrome**);*

*(B) One or more occurrences of an event that is not commonly associated with drug exposure, but is otherwise uncommon in the population exposed to the drug (e.g., tendon rupture**);*

*(C) An aggregate analysis of specific events observed in a clinical trial (such as known consequences of the underlying disease or condition under investigation or other events that commonly occur in the study population independent of drug therapy) that indicates those events occur more frequently in the drug treatment group than in a concurrent or historical control group.”*

*Furthermore, according to 21 CFR 312.32(c)(2), “the sponsor must also notify FDA of any unexpected fatal or life-threatening suspected adverse reaction as soon as possible but in no case later than 7 calendar days after the sponsor's initial receipt of the information.”*

*A**s noted previously, a**n unanticipated adverse device effect could** be considered **an SAE** (****Section 8.******3******.2, Definition of Serious Adverse Event******s******).**** ** **For IDE studies, according to 21 CFR 812.150(a)(1), “an investigator shall submit to the sponsor and to the reviewing IRB a report of any unanticipated adverse device effect occurring during an investigation as soon as possible, but in no event later than 10 working days after the investigator first learns of the effect.”**  In addition, according to 21 CFR 812.150(b)(1), “**A sponsor who conducts an evaluation of an unanticipated adverse device effect under 812.46(b) shall report the results of such evaluation to FDA and to all reviewing IRB's and participating investigators within 10 working days after the sponsor first receives notice of the effect. Thereafter the sponsor shall submit such additional reports concerning the effect as FDA requests.**”  *

*Example text** provided as a guide, customize as needed**:*

*Example 1, **applicable for a drug or biologic protocol**:*

[The study clinician will immediately report to the sponsor any serious adverse event, whether or not considered study intervention related, including those listed in the protocol or investigator brochure and must include an assessment of whether there is a reasonable possibility that the study intervention caused the event. Study endpoints that are serious adverse events (e.g., all-cause mortality) must be reported in accordance with the protocol unless there is evidence suggesting a causal relationship between the study intervention and the event (e.g., death from anaphylaxis). In that case, the investigator must immediately report the event to the sponsor.

All serious adverse events (SAEs) will be followed until satisfactory resolution or until the site investigator deems the event to be chronic or the participant is stable. Other supporting documentation of the event may be requested by the Data Coordinating Center (DCC)/study sponsor and should be provided as soon as possible.

The study sponsor will be responsible for notifying the Food and Drug Administration (FDA) of any unexpected fatal or life-threatening suspected adverse reaction as soon as possible, but in no case later than 7 calendar days after the sponsor's initial receipt of the information.  In addition, the sponsor must notify FDA and all participating investigators in an Investigational New Drug (IND) safety report of potential serious risks, from clinical trials or any other source, as soon as possible, but in no case later than 15 calendar days after the sponsor determines that the information qualifies for reporting.]

*OR *

*Example 2, applicable for **device **protocol:*

[The study investigator shall complete an Unanticipated Adverse Device Effect Form and submit to the study sponsor and to the reviewing Institutional Review Board (IRB) as soon as possible, but in no event later than 10 working days after the investigator first learns of the effect.  The study sponsor is responsible for conducting an evaluation of an unanticipated adverse device effect and shall report the results of such evaluation to the Food and Drug Administration (FDA) and to all reviewing IRBs and participating investigators within 10 working days after the sponsor first receives notice of the effect. Thereafter, the sponsor shall submit such additional reports concerning the effect as FDA requests.]

<Insert text>

### Reporting Events to Participants 

*Include content in this section if applicable, otherwise note as **not-applicable**.*

*Describe **how participants will be informed about AEs** and** SAEs, **and **study**-related** results** **on an individual or aggregate level.** In addition, describe plans for detecting and managing incidental findings associated with **study** procedures. **  *

<Insert text>

### Events of Special Interest 

*Include **content in **this section if applicable, otherwise **note as **not-applicable**.*

*Describe any other events that merit reporting to the sponsor, study leadership, IRB, and regulatory agencies.  For example, in oncology trials, secondary malignancies are often captured.  *

*Include any other reportable events not already included in the previous sections, such as cardiovascular and death events, medical device incidents (including malfunctions), laboratory test abnormalities, and** study intervention **overdose. *

<Insert text>

### Reporting of Pregnancy 

*Include** content in** this section if applicable, otherwise **note as **not-applicable**.** Pregnancy is not an adverse event, but some studies will require unique considerations if pregnancy was to occur during the study.*

*State the study’s pregnancy-related policy and procedure.  Include appropriate mechanisms for reporting to the DCC or NIH, the IND or IDE sponsor, study leadership, IRB, and regulatory agencies.  Provide appropriate modifications to study procedures (e.g., discontinuation of **study intervention, **while continuing safety follow-up, requesting permission to follow pregnant women to pregnancy outcome).*

<Insert text>

## Unanticipated Problems

*No text is to be **entered** in this section; rather it should be included under the relevant subheadings below.*

### Definition of Unanticipated Problems (UP)

*The reporting of UPs applies **to non-exempt human **subjects** research conducted or supported by HHS. **Provide the definition of an UP being used for this clinical trial. **An incident, experience, or outcome that meets the definition of an **UP** generally will warrant consideration of changes to the protocol or consent **in order to** protect the safety, welfare, or rights of **participant**s or others. Other **UP**s may warrant corrective actions at a specific study site. Examples of corrective actions or changes that might need to be considered in response to an **UP** include:*

- *M**odification of inclusion or exclusion criteria to mitigate the newly identified risks*

- *I**mplementation of additional safety monitoring procedures*

- *S**uspension of enrollment of new **participant**s or halting of study procedures for enrolled **participant**s *

- *M**odification of informed consent documents to include a description of newly recognized risks*

- *P**rovision of additional information about newly recognized risks to previously enrolled **participant**s*.

*Example text** provided as a guide, customize as needed**:*

[The Office for Human Research Protections (OHRP) considers unanticipated problems involving risks to participants or others to include, in general, any incident, experience, or outcome that meets **all** of the following criteria:

- Unexpected in terms of nature, severity, or frequency given (a) the research procedures that are described in the protocol-related documents, such as the Institutional Review Board (IRB)-approved research protocol and informed consent document; and (b) the characteristics of the participant population being studied;

- Related or possibly related to participation in the research (“possibly related” means there is a reasonable possibility that the incident, experience, or outcome may have been caused by the procedures involved in the research); and

- Suggests that the research places participants or others at a greater risk of harm (including physical, psychological, economic, or social harm) than was previously known or recognized.

*Additional example text, applicable for device protocol**s**:*

[This definition could include an unanticipated adverse device effect, any serious adverse effect on health or safety or any life-threatening problem or death caused by, or associated with, a device, if that effect, problem, or death was not previously identified in nature, severity, or degree of incidence in the investigational plan or application (including a supplementary plan or application), or any other unanticipated serious problem associated with a device that relates to the rights, safety, or welfare of subjects (21 CFR 812.3(s)).]

<Insert text>

###  Unanticipated Problem Reporting 

*This section addresses responsibilities of i**nvestigators for reporting of UP**s.  **Describe the **UP** reporting** procedures, including timeframes. **Further details should be i**nclude**d in a MOP or SOP including a** description and a flow chart of when events are reported to various oversight **(e.g., **DSMB**, safety monitoring committee, independent safety monitor) **and regulatory groups, and what study staff are responsible for completing and signing off on the **UP report** forms. *

*Institutions engaged in human **subjects** research conducted or supported by **Department of Health and Human Services (**DHHS**)** must have written procedures for ensuring prompt reporting to the IRB, appropriate institutional officials, and any supporting department or agency head of any unanticipated problem involving risks to subjects or others (45 CFR 46.103(b)(5)). Furthermore, for research covered by an assurance approved for federal wide use by OHRP, DHHS regulations at 45 CFR 46.103(a) require that institutions promptly report any unanticipated problems to OHRP.*

*Example text** provided as a guide, customize as needed**:*

[The investigator will report unanticipated problems (UPs) to the reviewing Institutional Review Board (IRB) and to the Data Coordinating Center (DCC)/lead principal investigator (PI). The UP report will include the following information:

- Protocol identifying information: protocol title and number, PI’s name, and the IRB project number;

- A detailed description of the event, incident, experience, or outcome; 

- An explanation of the basis for determining that the event, incident, experience, or outcome represents an UP; 

- A description of any changes to the protocol or other corrective actions that have been taken or are proposed in response to the UP.

To satisfy the requirement for prompt reporting, UPs will be reported using the following timeline:  

- UPs that are serious adverse events (SAEs) will be reported to the IRB and to the DCC/study sponsor within <insert timeline in accordance with policy> of the investigator becoming aware of the event. 

- Any other UP will be reported to the IRB and to the DCC/study sponsor within <insert timeline in accordance with policy> of the investigator becoming aware of the problem. 

- All UPs should be reported to appropriate institutional officials (as required by an institution’s written reporting procedures), the supporting agency head (or designee), and the Office for Human Research Protections (OHRP) within <insert timeline in accordance with policy> of the IRB’s receipt of the report of the problem from the investigator.]

*Additional example text, applicable for **device protocol**:*

[An investigator shall submit to the sponsor and to the reviewing Institutional Review Board (IRB) a report of any unanticipated adverse device effect occurring during an investigation as soon as possible, but in no event later than 10 working days after the investigator first learns of the effect (21 CFR 812.150(a)(1)), A sponsor who conducts an evaluation of an unanticipated adverse device effect under 812.46(b) shall report the results of such evaluation to the Food and Drug Administration (FDA) and to all reviewing IRB's and participating investigators within 10 working days after the sponsor first receives notice of the effect. Thereafter the sponsor shall submit such additional reports concerning the effect as FDA requests (21 CFR 812.150(b)(1)).   

<Insert text>

### Reporting Unanticipated Problems to Participants 

*Include content in this section if applicable, otherwise note as **not-applicable**.*

*Describe **how participants will be informed about UPs on an individual or aggregate level.  *

<Insert text>

